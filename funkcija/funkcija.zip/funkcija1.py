def say_hello():

    print('hello world')


say_hello()  
say_hello()  
